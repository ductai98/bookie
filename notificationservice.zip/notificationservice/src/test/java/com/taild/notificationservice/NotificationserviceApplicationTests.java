package com.taild.notificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
